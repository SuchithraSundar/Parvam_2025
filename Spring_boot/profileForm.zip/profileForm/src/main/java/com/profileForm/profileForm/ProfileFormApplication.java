package com.profileForm.profileForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfileFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfileFormApplication.class, args);
	}

}
